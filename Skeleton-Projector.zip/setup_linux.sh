sudo apt update
sudo apt install libopencv-dev python3-opencv